/*******************************************************************************
* File Name: isrR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isrR_H)
#define CY_ISR_isrR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isrR_Start(void);
void isrR_StartEx(cyisraddress address);
void isrR_Stop(void);

CY_ISR_PROTO(isrR_Interrupt);

void isrR_SetVector(cyisraddress address);
cyisraddress isrR_GetVector(void);

void isrR_SetPriority(uint8 priority);
uint8 isrR_GetPriority(void);

void isrR_Enable(void);
uint8 isrR_GetState(void);
void isrR_Disable(void);

void isrR_SetPending(void);
void isrR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isrR ISR. */
#define isrR_INTC_VECTOR            ((reg32 *) isrR__INTC_VECT)

/* Address of the isrR ISR priority. */
#define isrR_INTC_PRIOR             ((reg32 *) isrR__INTC_PRIOR_REG)

/* Priority of the isrR interrupt. */
#define isrR_INTC_PRIOR_NUMBER      isrR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isrR interrupt. */
#define isrR_INTC_SET_EN            ((reg32 *) isrR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isrR interrupt. */
#define isrR_INTC_CLR_EN            ((reg32 *) isrR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isrR interrupt state to pending. */
#define isrR_INTC_SET_PD            ((reg32 *) isrR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isrR interrupt. */
#define isrR_INTC_CLR_PD            ((reg32 *) isrR__INTC_CLR_PD_REG)



#endif /* CY_ISR_isrR_H */


/* [] END OF FILE */
