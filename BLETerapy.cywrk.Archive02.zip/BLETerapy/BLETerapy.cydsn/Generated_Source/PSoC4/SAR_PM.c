/*******************************************************************************
* File Name: SAR_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SAR.h"


/***************************************
* Local data allocation
***************************************/

static SAR_BACKUP_STRUCT  SAR_backup =
{
    SAR_DISABLED,
    0u    
};


/*******************************************************************************
* Function Name: SAR_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SAR_SaveConfig(void)
{
    /* All configuration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: SAR_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SAR_RestoreConfig(void)
{
    /* All configuration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: SAR_Sleep
********************************************************************************
*
* Summary:
*  Stops the ADC operation and saves the configuration registers and component
*  enable state. Should be called just prior to entering sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SAR_backup - modified.
*
*******************************************************************************/
void SAR_Sleep(void)
{
    /* During deepsleep/ hibernate mode keep SARMUX active, i.e. do not open
    *   all switches (disconnect), to be used for ADFT
    */
    SAR_backup.dftRegVal = SAR_SAR_DFT_CTRL_REG & (uint32)~SAR_ADFT_OVERRIDE;
    SAR_SAR_DFT_CTRL_REG |= SAR_ADFT_OVERRIDE;
    if((SAR_SAR_CTRL_REG  & SAR_ENABLE) != 0u)
    {
        if((SAR_SAR_SAMPLE_CTRL_REG & SAR_CONTINUOUS_EN) != 0u)
        {
            SAR_backup.enableState = SAR_ENABLED | SAR_STARTED;
        }
        else
        {
            SAR_backup.enableState = SAR_ENABLED;
        }
        SAR_StopConvert();
        SAR_Stop();
        
        /* Disable the SAR internal pump before entering the chip low power mode */
        if((SAR_SAR_CTRL_REG & SAR_BOOSTPUMP_EN) != 0u)
        {
            SAR_SAR_CTRL_REG &= (uint32)~SAR_BOOSTPUMP_EN;
            SAR_backup.enableState |= SAR_BOOSTPUMP_ENABLED;
        }
    }
    else
    {
        SAR_backup.enableState = SAR_DISABLED;
    }
}


/*******************************************************************************
* Function Name: SAR_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component enable state and configuration registers.
*  This should be called just after awaking from sleep mode.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SAR_backup - used.
*
*******************************************************************************/
void SAR_Wakeup(void)
{
    SAR_SAR_DFT_CTRL_REG = SAR_backup.dftRegVal;
    if(SAR_backup.enableState != SAR_DISABLED)
    {
        /* Enable the SAR internal pump  */
        if((SAR_backup.enableState & SAR_BOOSTPUMP_ENABLED) != 0u)
        {
            SAR_SAR_CTRL_REG |= SAR_BOOSTPUMP_EN;
        }
        SAR_Enable();
        if((SAR_backup.enableState & SAR_STARTED) != 0u)
        {
            SAR_StartConvert();
        }
    }
}
/* [] END OF FILE */
