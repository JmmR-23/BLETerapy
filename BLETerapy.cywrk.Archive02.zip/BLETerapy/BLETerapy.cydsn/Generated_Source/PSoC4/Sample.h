/*******************************************************************************
* File Name: Sample.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Sample_H)
#define CY_CLOCK_Sample_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void Sample_StartEx(uint32 alignClkDiv);
#define Sample_Start() \
    Sample_StartEx(Sample__PA_DIV_ID)

#else

void Sample_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void Sample_Stop(void);

void Sample_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 Sample_GetDividerRegister(void);
uint8  Sample_GetFractionalDividerRegister(void);

#define Sample_Enable()                         Sample_Start()
#define Sample_Disable()                        Sample_Stop()
#define Sample_SetDividerRegister(clkDivider, reset)  \
    Sample_SetFractionalDividerRegister((clkDivider), 0u)
#define Sample_SetDivider(clkDivider)           Sample_SetDividerRegister((clkDivider), 1u)
#define Sample_SetDividerValue(clkDivider)      Sample_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define Sample_DIV_ID     Sample__DIV_ID

#define Sample_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define Sample_CTRL_REG   (*(reg32 *)Sample__CTRL_REGISTER)
#define Sample_DIV_REG    (*(reg32 *)Sample__DIV_REGISTER)

#define Sample_CMD_DIV_SHIFT          (0u)
#define Sample_CMD_PA_DIV_SHIFT       (8u)
#define Sample_CMD_DISABLE_SHIFT      (30u)
#define Sample_CMD_ENABLE_SHIFT       (31u)

#define Sample_CMD_DISABLE_MASK       ((uint32)((uint32)1u << Sample_CMD_DISABLE_SHIFT))
#define Sample_CMD_ENABLE_MASK        ((uint32)((uint32)1u << Sample_CMD_ENABLE_SHIFT))

#define Sample_DIV_FRAC_MASK  (0x000000F8u)
#define Sample_DIV_FRAC_SHIFT (3u)
#define Sample_DIV_INT_MASK   (0xFFFFFF00u)
#define Sample_DIV_INT_SHIFT  (8u)

#else 

#define Sample_DIV_REG        (*(reg32 *)Sample__REGISTER)
#define Sample_ENABLE_REG     Sample_DIV_REG
#define Sample_DIV_FRAC_MASK  Sample__FRAC_MASK
#define Sample_DIV_FRAC_SHIFT (16u)
#define Sample_DIV_INT_MASK   Sample__DIVIDER_MASK
#define Sample_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_Sample_H) */

/* [] END OF FILE */
