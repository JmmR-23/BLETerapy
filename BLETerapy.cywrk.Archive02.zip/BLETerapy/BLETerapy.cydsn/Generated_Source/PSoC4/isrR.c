/*******************************************************************************
* File Name: isrR.c  
* Version 1.70
*
*  Description:
*   API for controlling the state of an interrupt.
*
*
*  Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/


#include <cydevice_trm.h>
#include <CyLib.h>
#include <isrR.h>
#include "cyapicallbacks.h"

#if !defined(isrR__REMOVED) /* Check for removal by optimization */

/*******************************************************************************
*  Place your includes, defines and code here 
********************************************************************************/
/* `#START isrR_intc` */

/* `#END` */

extern cyisraddress CyRamVectors[CYINT_IRQ_BASE + CY_NUM_INTERRUPTS];

/* Declared in startup, used to set unused interrupts to. */
CY_ISR_PROTO(IntDefaultHandler);


/*******************************************************************************
* Function Name: isrR_Start
********************************************************************************
*
* Summary:
*  Set up the interrupt and enable it. This function disables the interrupt, 
*  sets the default interrupt vector, sets the priority from the value in the
*  Design Wide Resources Interrupt Editor, then enables the interrupt to the 
*  interrupt controller.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrR_Start(void)
{
    /* For all we know the interrupt is active. */
    isrR_Disable();

    /* Set the ISR to point to the isrR Interrupt. */
    isrR_SetVector(&isrR_Interrupt);

    /* Set the priority. */
    isrR_SetPriority((uint8)isrR_INTC_PRIOR_NUMBER);

    /* Enable it. */
    isrR_Enable();
}


/*******************************************************************************
* Function Name: isrR_StartEx
********************************************************************************
*
* Summary:
*  Sets up the interrupt and enables it. This function disables the interrupt,
*  sets the interrupt vector based on the address passed in, sets the priority 
*  from the value in the Design Wide Resources Interrupt Editor, then enables 
*  the interrupt to the interrupt controller.
*  
*  When defining ISR functions, the CY_ISR and CY_ISR_PROTO macros should be 
*  used to provide consistent definition across compilers:
*  
*  Function definition example:
*   CY_ISR(MyISR)
*   {
*   }
*   Function prototype example:
*   CY_ISR_PROTO(MyISR);
*
* Parameters:  
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void isrR_StartEx(cyisraddress address)
{
    /* For all we know the interrupt is active. */
    isrR_Disable();

    /* Set the ISR to point to the isrR Interrupt. */
    isrR_SetVector(address);

    /* Set the priority. */
    isrR_SetPriority((uint8)isrR_INTC_PRIOR_NUMBER);

    /* Enable it. */
    isrR_Enable();
}


/*******************************************************************************
* Function Name: isrR_Stop
********************************************************************************
*
* Summary:
*   Disables and removes the interrupt.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrR_Stop(void)
{
    /* Disable this interrupt. */
    isrR_Disable();

    /* Set the ISR to point to the passive one. */
    isrR_SetVector(&IntDefaultHandler);
}


/*******************************************************************************
* Function Name: isrR_Interrupt
********************************************************************************
*
* Summary:
*   The default Interrupt Service Routine for isrR.
*
*   Add custom code between the START and END comments to keep the next version
*   of this file from over-writing your code.
*
*   Note You may use either the default ISR by using this API, or you may define
*   your own separate ISR through ISR_StartEx().
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
CY_ISR(isrR_Interrupt)
{
    #ifdef isrR_INTERRUPT_INTERRUPT_CALLBACK
        isrR_Interrupt_InterruptCallback();
    #endif /* isrR_INTERRUPT_INTERRUPT_CALLBACK */ 

    /*  Place your Interrupt code here. */
    /* `#START isrR_Interrupt` */

    /* `#END` */
}


/*******************************************************************************
* Function Name: isrR_SetVector
********************************************************************************
*
* Summary:
*   Change the ISR vector for the Interrupt. Note calling isrR_Start
*   will override any effect this method would have had. To set the vector 
*   before the component has been started use isrR_StartEx instead.
* 
*   When defining ISR functions, the CY_ISR and CY_ISR_PROTO macros should be 
*   used to provide consistent definition across compilers:
*
*   Function definition example:
*   CY_ISR(MyISR)
*   {
*   }
*
*   Function prototype example:
*     CY_ISR_PROTO(MyISR);
*
* Parameters:
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void isrR_SetVector(cyisraddress address)
{
    CyRamVectors[CYINT_IRQ_BASE + isrR__INTC_NUMBER] = address;
}


/*******************************************************************************
* Function Name: isrR_GetVector
********************************************************************************
*
* Summary:
*   Gets the "address" of the current ISR vector for the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Address of the ISR in the interrupt vector table.
*
*******************************************************************************/
cyisraddress isrR_GetVector(void)
{
    return CyRamVectors[CYINT_IRQ_BASE + isrR__INTC_NUMBER];
}


/*******************************************************************************
* Function Name: isrR_SetPriority
********************************************************************************
*
* Summary:
*   Sets the Priority of the Interrupt. 
*
*   Note calling isrR_Start or isrR_StartEx will 
*   override any effect this API would have had. This API should only be called
*   after isrR_Start or isrR_StartEx has been called. 
*   To set the initial priority for the component, use the Design-Wide Resources
*   Interrupt Editor.
*
*   Note This API has no effect on Non-maskable interrupt NMI).
*
* Parameters:
*   priority: Priority of the interrupt, 0 being the highest priority
*             PSoC 3 and PSoC 5LP: Priority is from 0 to 7.
*             PSoC 4: Priority is from 0 to 3.
*
* Return:
*   None
*
*******************************************************************************/
void isrR_SetPriority(uint8 priority)
{
	uint8 interruptState;
    uint32 priorityOffset = ((isrR__INTC_NUMBER % 4u) * 8u) + 6u;
    
	interruptState = CyEnterCriticalSection();
    *isrR_INTC_PRIOR = (*isrR_INTC_PRIOR & (uint32)(~isrR__INTC_PRIOR_MASK)) |
                                    ((uint32)priority << priorityOffset);
	CyExitCriticalSection(interruptState);
}


/*******************************************************************************
* Function Name: isrR_GetPriority
********************************************************************************
*
* Summary:
*   Gets the Priority of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Priority of the interrupt, 0 being the highest priority
*    PSoC 3 and PSoC 5LP: Priority is from 0 to 7.
*    PSoC 4: Priority is from 0 to 3.
*
*******************************************************************************/
uint8 isrR_GetPriority(void)
{
    uint32 priority;
	uint32 priorityOffset = ((isrR__INTC_NUMBER % 4u) * 8u) + 6u;

    priority = (*isrR_INTC_PRIOR & isrR__INTC_PRIOR_MASK) >> priorityOffset;

    return (uint8)priority;
}


/*******************************************************************************
* Function Name: isrR_Enable
********************************************************************************
*
* Summary:
*   Enables the interrupt to the interrupt controller. Do not call this function
*   unless ISR_Start() has been called or the functionality of the ISR_Start() 
*   function, which sets the vector and the priority, has been called.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrR_Enable(void)
{
    /* Enable the general interrupt. */
    *isrR_INTC_SET_EN = isrR__INTC_MASK;
}


/*******************************************************************************
* Function Name: isrR_GetState
********************************************************************************
*
* Summary:
*   Gets the state (enabled, disabled) of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   1 if enabled, 0 if disabled.
*
*******************************************************************************/
uint8 isrR_GetState(void)
{
    /* Get the state of the general interrupt. */
    return ((*isrR_INTC_SET_EN & (uint32)isrR__INTC_MASK) != 0u) ? 1u:0u;
}


/*******************************************************************************
* Function Name: isrR_Disable
********************************************************************************
*
* Summary:
*   Disables the Interrupt in the interrupt controller.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrR_Disable(void)
{
    /* Disable the general interrupt. */
    *isrR_INTC_CLR_EN = isrR__INTC_MASK;
}


/*******************************************************************************
* Function Name: isrR_SetPending
********************************************************************************
*
* Summary:
*   Causes the Interrupt to enter the pending state, a software method of
*   generating the interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
* Side Effects:
*   If interrupts are enabled and the interrupt is set up properly, the ISR is
*   entered (depending on the priority of this interrupt and other pending 
*   interrupts).
*
*******************************************************************************/
void isrR_SetPending(void)
{
    *isrR_INTC_SET_PD = isrR__INTC_MASK;
}


/*******************************************************************************
* Function Name: isrR_ClearPending
********************************************************************************
*
* Summary:
*   Clears a pending interrupt in the interrupt controller.
*
*   Note Some interrupt sources are clear-on-read and require the block 
*   interrupt/status register to be read/cleared with the appropriate block API 
*   (GPIO, UART, and so on). Otherwise the ISR will continue to remain in 
*   pending state even though the interrupt itself is cleared using this API.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrR_ClearPending(void)
{
    *isrR_INTC_CLR_PD = isrR__INTC_MASK;
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
